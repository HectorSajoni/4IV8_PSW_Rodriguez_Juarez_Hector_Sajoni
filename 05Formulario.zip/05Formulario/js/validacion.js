/*
javascript es un lenguaje que pose un paradigma orientado a objetos y a funciones, 
por lo tanto presenta una particularidad la cual es

NO TIPADO

no existe int, double, float, String, etc.

dentro de JS, todo es VAR -> variable

De acuerdo al estándar de ES6 se manejan 3 tipos de variables

VAR
LET Es una variable de tipo protected
CONST
*/
function validar(formulario)
{
    if(formulario.nombre.value.length < 5)
    {
        alert("Escriba por lo menos 5 caracteres para el nombre");
        formulario.nombre.focus();
        return false;
    }
    var checkOK = "qwertyuiopasdfghjklñzxcvbnm"+"QWERTYUIOPASDFGHJKLÑZXCVBNM";
    var checkSTR = formulario.nombre.value;
    var allValido = true;
    for(var i = 0; i < checkSTR.length; i++)
    {
        var ch = checkSTR.charAT(i);
        for(var j = 0; j < checkOK.length; j++)
        {
           if(ch == checkOK.charAt(j))
           break; 
        }
        if(j == checkOK.length)
        {
            allValido = false;
            break;
        }
    }
    if(!allValido)
    {
        alert("hola");
        alert("Escriba unicamente letras en el campo de nombre");
        formulario.nombre.focus();
        return false;
    }
    var checkOK = "0123456789";
    var checkSTR = formulario.nombre.value;
    var allValido = true;
    for(var i = 0; i < checkSTR.length; i++)
    {
        var ch = checkSTR.charAT(i);
        for(var j = 0; j < checkOK.length; j++)
        {
           if(ch == checkOK.charAt(j))
           break; 
        }
        if(j == checkOK.length)
        {
            allValido = false;
            break;
        }
    }
    if(!allValido)
    {
        alert("Escriba unicamente números en el campo de edad");
        formulario.nombre.focus();
        return false;
    }
    /*
    Es necesario que busques expresiones regualres para poder validar la entrada de datos
    */
   var txt = formulario.email.value;

   //crear mi expresion

   var b = /^[^@\s]+[^@\.\s]+(\.[^@\.\s]+)+$/;
   alert("Email "+(b.test(txt)?" ":"no")+" valido");
   return b.test;
}